﻿#include "base.h"
#include <iostream>
#include <fstream>
#include <sstream>

BaseObject::BaseObject() : VBO(0), VAO(0), EBO(0), shaderProgram(0) {}

BaseObject::~BaseObject() {
    glDeleteBuffers(1, &VBO);
    glDeleteBuffers(1, &EBO);
    glDeleteVertexArrays(1, &VAO);
    glDeleteProgram(shaderProgram);
}

void BaseObject::Init() {
    SetupShaders();
    SetupCube();
}

void BaseObject::SetupShaders() {
    const char* vertexShaderSource = R"(
    #version 330 core
    layout (location = 0) in vec3 aPos;
    layout (location = 1) in vec3 aColor;
    out vec3 vertexColor; // Przekazujemy kolor do fragment shaderu
    uniform mat4 model;
    uniform mat4 view;
    uniform mat4 projection;
    void main() {
        gl_Position = projection * view * model * vec4(aPos, 1.0);
        vertexColor = aColor; // Przypisanie koloru do zmiennej, która będzie przekazywana do fragment shaderu
    })";


    const char* fragmentShaderSource = R"(
    #version 330 core
    in vec3 vertexColor; // Odbieramy kolor z vertex shadera
    out vec4 FragColor;
    void main() {
        FragColor = vec4(vertexColor, 1.0); // Używamy koloru wierzchołka
    })";


    GLuint vertexShader, fragmentShader;

    // Kompilacja vertex shader
    vertexShader = glCreateShader(GL_VERTEX_SHADER);
    glShaderSource(vertexShader, 1, &vertexShaderSource, nullptr);
    glCompileShader(vertexShader);

    // Kompilacja fragment shader
    fragmentShader = glCreateShader(GL_FRAGMENT_SHADER);
    glShaderSource(fragmentShader, 1, &fragmentShaderSource, nullptr);
    glCompileShader(fragmentShader);

    // Tworzenie programu shaderów
    shaderProgram = glCreateProgram();
    glAttachShader(shaderProgram, vertexShader);
    glAttachShader(shaderProgram, fragmentShader);
    glLinkProgram(shaderProgram);

    // Usuwanie shaderów po linkowaniu
    glDeleteShader(vertexShader);
    glDeleteShader(fragmentShader);
}

void BaseObject::SetupCube() {
    // Wierzchołki sześcianu (x, y, z, r, g, b)
    float vertices[] = {
        // Front face (niebieski)
        -0.5f, -0.5f, -0.5f,  0.0f, 0.0f, 1.0f,  // niebieski
         0.5f, -0.5f, -0.5f,  0.0f, 0.0f, 1.0f,  // niebieski
         0.5f,  0.5f, -0.5f,  0.0f, 0.0f, 1.0f,  // niebieski
        -0.5f,  0.5f, -0.5f,  0.0f, 0.0f, 1.0f,  // niebieski

        // Back face (czerwony)
        -0.5f, -0.5f,  0.5f,  1.0f, 0.0f, 0.0f,  // czerwony
         0.5f, -0.5f,  0.5f,  1.0f, 0.0f, 0.0f,  // czerwony
         0.5f,  0.5f,  0.5f,  1.0f, 0.0f, 0.0f,  // czerwony
        -0.5f,  0.5f,  0.5f,  1.0f, 0.0f, 0.0f,  // czerwony

        // Bottom face (zielony)
        -0.5f, -0.5f,  0.5f,  0.0f, 1.0f, 0.0f,  // zielony
         0.5f, -0.5f,  0.5f,  0.0f, 1.0f, 0.0f,  // zielony
         0.5f, -0.5f, -0.5f,  0.0f, 1.0f, 0.0f,  // zielony
        -0.5f, -0.5f, -0.5f,  0.0f, 1.0f, 0.0f,  // zielony

        // Top face (żółty)
        -0.5f,  0.5f,  0.5f,  1.0f, 1.0f, 0.0f,  // żółty
         0.5f,  0.5f,  0.5f,  1.0f, 1.0f, 0.0f,  // żółty
         0.5f,  0.5f, -0.5f,  1.0f, 1.0f, 0.0f,  // żółty
        -0.5f,  0.5f, -0.5f,  1.0f, 1.0f, 0.0f,  // żółty

        // Right face (fioletowy)
         0.5f, -0.5f, -0.5f,  1.0f, 0.0f, 1.0f,  // fioletowy
         0.5f, -0.5f,  0.5f,  1.0f, 0.0f, 1.0f,  // fioletowy
         0.5f,  0.5f,  0.5f,  1.0f, 0.0f, 1.0f,  // fioletowy
         0.5f,  0.5f, -0.5f,  1.0f, 0.0f, 1.0f,  // fioletowy

         // Left face (pomarańczowy)
         -0.5f, -0.5f, -0.5f,  1.0f, 0.5f, 0.0f,  // pomarańczowy
         -0.5f, -0.5f,  0.5f,  1.0f, 0.5f, 0.0f,  // pomarańczowy
         -0.5f,  0.5f,  0.5f,  1.0f, 0.5f, 0.0f,  // pomarańczowy
         -0.5f,  0.5f, -0.5f,  1.0f, 0.5f, 0.0f   // pomarańczowy
    };

    GLuint indices[] = {
        0, 1, 2, 2, 3, 0, // Front
        4, 5, 6, 6, 7, 4, // Back
        8, 9, 10, 10, 11, 8, // Bottom
        12, 13, 14, 14, 15, 12, // Top
        16, 17, 18, 18, 19, 16, // Right
        20, 21, 22, 22, 23, 20  // Left
    };

    // Tworzenie VAO, VBO, EBO
    glGenVertexArrays(1, &VAO);
    glGenBuffers(1, &VBO);
    glGenBuffers(1, &EBO);

    glBindVertexArray(VAO);

    // VBO - Wierzchołki z kolorami
    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

    // EBO - Indeksy
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

    // Definicja atrybutu pozycji wierzchołka (x, y, z)
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);

    // Definicja atrybutu koloru wierzchołka (r, g, b)
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);

    glBindVertexArray(0);
}


void BaseObject::Draw(const glm::mat4& view, const glm::mat4& projection) {
    glUseProgram(shaderProgram);

    glm::mat4 model = glm::mat4(1.0f);
    glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "model"), 1, GL_FALSE, &model[0][0]);
    glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "view"), 1, GL_FALSE, &view[0][0]);
    glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "projection"), 1, GL_FALSE, &projection[0][0]);

    glBindVertexArray(VAO);
    glDrawElements(GL_TRIANGLES, 36, GL_UNSIGNED_INT, 0);
    glBindVertexArray(0);
}

void BaseObject::DrawBase(const glm::mat4& view, const glm::mat4& projection) {
    glUseProgram(shaderProgram);
    glm::mat4 model = glm::mat4(1.0f);
    // Przesunięcie obiektu
    model = glm::translate(model, glm::vec3(0.0f, -0.5f, 0.0f));
    model = glm::scale(model, glm::vec3(6.0f, 0.1f, 6.0f));

    // Obrót obiektu wokół osi Y (np. o 45 stopni)
    float angle = 45.0f;  // Kąt rotacji
    //model = glm::rotate(model, glm::radians(angle), glm::vec3(0.0f, 1.0f, 0.0f)); // Obrót wokół osi Y
    //model = glm::rotate(model, glm::radians(90.0f), glm::vec3(1.0f, 0.0f, 0.0f)); // Obrót wokół osi X
    //model = glm::rotate(model, glm::radians(90.0f), glm::vec3(0.0f, 0.0f, 1.0f)); // Obrót wokół osi Z

    
    glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "model"), 1, GL_FALSE, &model[0][0]);
    glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "view"), 1, GL_FALSE, &view[0][0]);
    glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "projection"), 1, GL_FALSE, &projection[0][0]);

    glBindVertexArray(VAO);
    glDrawElements(GL_TRIANGLES, 36, GL_UNSIGNED_INT, 0);
    glBindVertexArray(0);
}
