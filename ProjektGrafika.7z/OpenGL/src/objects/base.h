﻿#ifndef BASE_OBJECT_H
#define BASE_OBJECT_H

#include <GL/glew.h>
#include <glm.hpp>
#include <gtc/matrix_transform.hpp>

class BaseObject {
public:
    BaseObject();
    ~BaseObject();

    void Init();  // Inicjalizacja obiektu
    void Draw(const glm::mat4& view, const glm::mat4& projection);  // Rysowanie sześcianu
    void DrawBase(const glm::mat4& view, const glm::mat4& projection);

private:
    GLuint VBO, VAO, EBO;  // VBO - Vertex Buffer Object, VAO - Vertex Array Object, EBO - Element Buffer Object
    GLuint shaderProgram;

    void SetupShaders();  // Inicjalizacja shaderów
    void SetupCube();  // Ustawienie wierzchołków i indeksów sześcianu
};

#endif