﻿#ifndef CUBOID_H
#define CUBOID_H

#include <GL/glew.h>
#include <glm.hpp>
#include <gtc/matrix_transform.hpp>

class Cuboid {
public:
    Cuboid();
    ~Cuboid();

    void Init();  // Inicjalizacja obiektu

    // Funkcje rysujące z dodatkowym parametrem wspólnej transformacji
    void Draw(const glm::mat4& view, const glm::mat4& projection, const glm::mat4& sharedModel, float rotationAngleY);
    void DrawCubeBottom(const glm::mat4& view, const glm::mat4& projection, const glm::mat4& sharedModel, float rotationAngleY);
    void DrawCubeTop(const glm::mat4& view, const glm::mat4& projection, const glm::mat4& sharedModel, float rotationAngleY, float sharedTranslationY);
    void DrawArm(const glm::mat4& view, const glm::mat4& projection, const glm::mat4& sharedModel, float rotationAngleY, float sharedTranslationY);
    void DrawArmDown(const glm::mat4& view, const glm::mat4& projection, const glm::mat4& sharedModel, float rotationAngleY, float sharedTranslationX, float sharedTranslationY);
    void DrawArmDown2(const glm::mat4& view, const glm::mat4& projection, const glm::mat4& sharedModel, float rotationAngleY, float rotationAngleX, float sharedTranslationX, float sharedTranslationY);

private:
    GLuint VBO, VAO, EBO;  // VBO - Vertex Buffer Object, VAO - Vertex Array Object, EBO - Element Buffer Object
    GLuint shaderProgram;

    void SetupShaders();  // Inicjalizacja shaderów
    void SetupCuboid();   // Ustawienie wierzchołków i indeksów prostopadłościanu
};

#endif
