﻿#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <iostream>
#include "objects/base.h"
#include "objects/cuboid.h"
#include <glm.hpp>
#include <gtc/matrix_transform.hpp>
#include <gtc/type_ptr.hpp>

int main() {
    // Inicjalizacja GLFW
    if (!glfwInit()) {
        std::cerr << "Nie udało się zainicjować GLFW!" << std::endl;
        return -1;
    }

    // Tworzenie okna
    GLFWwindow* window = glfwCreateWindow(800, 600, "Sześcian 3D", nullptr, nullptr);
    if (!window) {
        std::cerr << "Nie udało się stworzyć okna!" << std::endl;
        glfwTerminate();
        return -1;
    }

    // Ustawienie kontekstu OpenGL
    glfwMakeContextCurrent(window);
    glfwSetFramebufferSizeCallback(window, [](GLFWwindow*, int width, int height) {
        glViewport(0, 0, width, height);
        });

    // Inicjalizacja GLEW
    if (glewInit() != GLEW_OK) {
        std::cerr << "Nie udało się zainicjować GLEW!" << std::endl;
        return -1;
    }

    // Inicjalizacja obiektów typu Cuboid


    BaseObject base;
    base.Init();

    Cuboid cuboid;
    cuboid.Init();

    Cuboid cubeBottom;
    cubeBottom.Init();

    Cuboid cubeTop;
    cubeTop.Init();

    Cuboid arm;
    arm.Init();

    Cuboid armDown;
    armDown.Init();

    // Pozycja kamery
    glm::vec3 cameraPos = glm::vec3(1.5f, 5.0f, 7.0f); 
    glm::vec3 cameraTarget = glm::vec3(0.0f, 2.0f, 0.0f);
    glm::vec3 up = glm::vec3(0.0f, 1.0f, 0.0f);

    // Macierz widoku
    glm::mat4 view = glm::lookAt(cameraPos, cameraTarget, up);

    // perspektywa
    glm::mat4 projection = glm::perspective(glm::radians(45.0f), 800.0f / 600.0f, 0.1f, 100.0f);

    // Macierz transformacji
    glm::mat4 sharedModel = glm::mat4(1.0f);


    float rotationAngleY = 0.0f;  // Globalna Y
    float rotationAngleX = 0.0f;  // Globalna X
    float sharedTranslationX = 0.0f;
    float sharedTranslationY = 0.0f;

    // Pętla renderująca
    while (!glfwWindowShouldClose(window)) {
        // Obsługa rotacji obiektu
        if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS) {
            rotationAngleY += 0.1f; // Rotacja w lewo
        }
        if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS) {
            rotationAngleY -= 0.1f; // Rotacja w prawo
        }
        // Wciśnięcie klawisza 'W' (góra)
        if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS) {
            rotationAngleX += 0.1f;  // Rotacja w górę
        }
        // Wciśnięcie klawisza 'S' (dół)
        if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS) {
            rotationAngleX -= 0.1f;  // Rotacja w dół
        }
        // Wciśnięcie klawisza 'LEFT' - strzalka w lewo 
        if (glfwGetKey(window, GLFW_KEY_LEFT) == GLFW_PRESS) {
            if (sharedTranslationX > -2.0f) {
                sharedTranslationX -= 0.001f; // Przesunięcie w lewo
            }
        }
        // Wciśnięcie klawisza 'RIGHT' - strzalka w prawo
        if (glfwGetKey(window, GLFW_KEY_RIGHT) == GLFW_PRESS) {
            if (sharedTranslationX < 2.0f) {
                sharedTranslationX += 0.001f; // Przesunięcie w prawo
            }
        }
        // Wciśnięcie klawisza 'UP' - strzalka w górę
        if (glfwGetKey(window, GLFW_KEY_UP) == GLFW_PRESS) {
            if (sharedTranslationY < 0.2f) {
                sharedTranslationY += 0.001f; // Przesunięcie w górę
            }
        }
        // Wciśnięcie klawisza 'DOWN' - strzalka w dół
        if (glfwGetKey(window, GLFW_KEY_DOWN) == GLFW_PRESS) {
            if (sharedTranslationY > - 2.0f) {
                sharedTranslationY -= 0.001f; // Przesunięcie w dół
            }
        }
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        glEnable(GL_DEPTH_TEST); 

        base.DrawBase(view, projection); // Podstawa kwadratowa
        cubeBottom.DrawCubeBottom(view, projection, sharedModel, rotationAngleY); // Kostka dolna
        cubeTop.DrawCubeTop(view, projection, sharedModel, rotationAngleY, sharedTranslationY); // Kostka górna - z ramieniem
        cuboid.Draw(view, projection, sharedModel, rotationAngleY);          // Główny prostopadłościan - pion
        arm.DrawArm(view, projection, sharedModel, rotationAngleY, sharedTranslationY);          // Ramię
        armDown.DrawArmDown(view, projection, sharedModel, rotationAngleY, sharedTranslationX, sharedTranslationY);   // Kostka ramienia w dół
        armDown.DrawArmDown2(view, projection, sharedModel, rotationAngleY, rotationAngleX, sharedTranslationX, sharedTranslationY);   // Ramię w dół


        // Przełączanie buforów i obsługa zdarzeń
        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    glfwTerminate();
    return 0;
}
